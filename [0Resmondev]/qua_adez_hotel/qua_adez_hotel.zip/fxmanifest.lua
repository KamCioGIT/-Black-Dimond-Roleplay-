fx_version 'bodacious'
game 'gta5'
lua54 'yes'

author 'QUADRIA'
description 'HOTELS'

this_is_a_map 'yes'


client_script {
    "qua_adez_hotel_k_shells.lua",
    "qua_adez_hotel_o_shells.lua",
    "qua_adez_hotel_b_shells.lua"
}


 
escrow_ignore {
    "qua_adez_hotel_k_shells.lua",
    "qua_adez_hotel_o_shells.lua",
    "qua_adez_hotel_b_shells.lua",
    'stream/b/*.ydr', 
    'stream/b/*.yft',     
    'stream/g/*.ydr', 
    'stream/g/*.yft',    
    'stream/k/*.ydr', 
    'stream/k/*.yft',   
    'stream/o/*.ydr', 
    'stream/o/*.yft',   
}


          -- Created by Quadria for 0Resmon --
--   ________                    .___      .__           --
--   \_____  \  __ _______     __| _/______|__|____      --
--    /  / \  \|  |  \__  \   / __ |\_  __ \  \__  \     --
--   /   \_/.  \  |  // __ \_/ /_/ | |  | \/  |/ __ \_   --
--   \_____\ \_/____/(____  /\____ | |__|  |__(____  /   --
--         \__>          \/      \/               \/     --

